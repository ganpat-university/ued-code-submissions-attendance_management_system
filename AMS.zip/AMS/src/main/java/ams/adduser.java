package ams;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@WebServlet(urlPatterns="/adduser")
public class adduser extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public adduser() {
        super();
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException 
    {
    	try{  
    		Class.forName("com.mysql.jdbc.Driver");  
    		  
    		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/attendance_management_system","root","1234");  
    		
    		String username = request.getParameter("user_name"); 
    		String email = request.getParameter("user_email"); 
    		String password = request.getParameter("user_password");
    		String role = request.getParameter("role"); 
    		int executed = 0;
    		
    		if(role.equals("admin"))
    		{
    			PreparedStatement stmt=con.prepareStatement("insert into "+role+" values(?,?,?,?)");    
        		stmt.setString(1,email);
        		stmt.setString(2,password);
        		stmt.setString(3,username);
        		stmt.setString(4,role);
        		executed = stmt.executeUpdate();
    		}
    		else if(role.equals("teacher"))
    		{
    			PreparedStatement stmt=con.prepareStatement("insert into "+role+" values(?,?,?,?)");    
        		stmt.setString(1,email);
        		stmt.setString(2,password);
        		stmt.setString(3,username);
        		stmt.setString(4,role);
        		executed = stmt.executeUpdate();
    		}

    		else if(role.equals("student"))
    		{
    			PreparedStatement stmt=con.prepareStatement("insert into "+role+" values(?,?,?,?)");    
        		stmt.setString(1,email);
        		stmt.setString(2,password);
        		stmt.setString(3,username);
        		stmt.setString(4,role);
        		executed = stmt.executeUpdate();
    		}
    		response.setContentType("text/html");
    		PrintWriter out=response.getWriter();
    		
    		
    		
    		if(executed == 1)
    		{
    			
    			
    			out.println("<script type=\"text/javascript\">");
    			out.println("alert('Data added successfully');");
    			out.println(" window.location.href = \"list.jsp\"");
    			out.println("</script>");
    		}
    		else 
    		{
    			response.getWriter().append("<h1>"+"Data Not Added To Database"+"</h1>"); 
    		}
    		  
    		  
    		con.close();  
    		  
    		}
    	
    	catch(Exception e)
    	{ 
    		System.out.println(e);
    	}  
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    doGet(request, response);
    }
}