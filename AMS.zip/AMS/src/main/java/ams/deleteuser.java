package ams;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@WebServlet(urlPatterns="/deleteuser")
public class deleteuser extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public deleteuser() {
        super();
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException 
    {
    	try{  
    		Class.forName("com.mysql.jdbc.Driver");  
    		  
    		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/attendance_management_system","root","1234");  
    		
    		String delete_email = request.getParameter("user_email"); 
    		String role = request.getParameter("role"); 
    		
    		PreparedStatement stmt=con.prepareStatement("DELETE FROM "+role+" WHERE email = ?");    
    		stmt.setString(1,delete_email);
    		int executed = stmt.executeUpdate();
    		
    		PrintWriter out = response.getWriter();
    		
    		if(executed == 1)
    		{
    			
    			
				
				  out.println("<script type=\"text/javascript\">");
				  out.println("alert('Data removed successfully');");
				  out.println(" window.location.href = \"list.jsp\"");
				  out.println("</script>");
    		}
    		else 
    		{
    			response.getWriter().append("<h1>"+"Data Not Added To Database"+"</h1>"); 
    		}
    		  
    		  
    		con.close();  
    		  
    		}
    	
    	catch(Exception e)
    	{ 
    		System.out.println(e);
    	}  
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    doGet(request, response);
    }
}